package com.project.commercebank2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommerceBank2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
