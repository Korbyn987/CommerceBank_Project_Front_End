package com.project.commercebank2024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceBank2024Application {

    public static void main(String[] args) {SpringApplication.run(CommerceBank2024Application.class, args);}
}
